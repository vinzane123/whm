This module remove Odoo branding on website:

* Remove "Create a free website with Odoo" from footer
